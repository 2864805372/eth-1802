// 与WeiboRegistry和WeiboAccount的交互
var contract = require("truffle-contract");
var Web3 = require("web3");

var WeiboRegistryArtifact = require("../../build/contracts/WeiboRegistry.json");
var WeiboAccountArtifact = require("../../build/contracts/WeiboAccount.json");

const WeiboRegistry = contract(WeiboRegistryArtifact);
const WeiboAccount = contract(WeiboAccountArtifact);

// 设置网络
var provider = new Web3.providers.HttpProvider("http://localhost:7545");
WeiboRegistry.setProvider(provider);
WeiboAccount.setProvider(provider);

/***********WeiboRegistry合约交互***********/
// WeiboRegistry 合约地址(可以用于部署WeiboAccount)
var weiboRegistryAddress = "0x0903b70c13232f96f4675bb254374220590ab67b";

var defaultGas = 4700000; // 默认gas

var currentWeiboAddress;

function register() {
    var weiboRegistryInstance;
    var name = $("#weiboName").val(); // 获取输入名称
    //var accountAddress = $("#weiboAccount").val(); //获取输入账号

    var weiboAccountAddress;// 个人微博合约地址
    WeiboAccount.new({from:WeiboRegistry.web3.eth.accounts[0],gas:defaultGas}).then(function(instance){
        weiboAccountAddress = instance.address;
        currentWeiboAddress = weiboAccountAddress;
        $("#weiboAccount").val(weiboAccountAddress);
    }).then(function(){
        WeiboRegistry.at(weiboRegistryAddress).then(function(instance){
            weiboRegistryInstance = instance;
            return weiboRegistryInstance.register(name, weiboAccountAddress,{
                from:WeiboRegistry.web3.eth.accounts[0],
                gas:defaultGas
            });
        }).then(function(txReceipt) {
            console.info(txReceipt);
            // TODO 显示平台所有已注册账户
            showAllRegister();
        });
    });
}

// 显示所有已注册账户
function showAllRegister() {
    getAllRegister().then(function(list){
        $("#weiboList").html('');
        list.forEach(function(item, index){
            $("#weiboList").append("<tr><td>" + item.id + "</td><td>" + item.name + "</td><td>" + item.addr + "</td></tr>");
            currentWeiboAddress = list[0].addr || "";
        });
    });
}

// 获取已注册微博账户总数
function getTotalRegisterUser() {
    return WeiboRegistry.at(weiboRegistryAddress).then(function(instance){
        return instance.getNumberOfAccounts.call();
    }).then(function(total){
        return total;
    });
}

// 通过ID查找指定账户
function getRegisterUser(id) {
    var addr;
    var weiboRegistryInstance;
    return WeiboRegistry.at(weiboRegistryAddress).then(function(insance){
        weiboRegistryInstance = insance;
        return weiboRegistryInstance.getAccOfId.call(id).then(function(a){
            addr = a;
            return weiboRegistryInstance.getNameOfAccount.call(addr);
        }).then(function(name){
            return {id:id, name : name, addr : addr};
        });
    });
}

// 获取所有账户
async function getAllRegister() {
    let users = [];
    let total = await getTotalRegisterUser();
    for (let i = 0; i < total;i++) { // 遍历ID
        let user = await getRegisterUser(i);
        users.push(user);// 追加
    }
    return users;
}

// 微博平台基本信息
async function getPlantformInfo() {
    $("#plantformAccount").html(weiboRegistryAddress);
    var weiboAccountNumber = await getTotalRegisterUser();
    console.info("weiboAccountNumber : ", weiboAccountNumber);
    $("#plantformNumber").html(weiboAccountNumber.c[0]);
}

/*WeiboAccount交互*/

// 发送微博
function sendWeibo() {
    var weiboAccountInstance;
    var weiboContent = $("#weiboContent").val(); // 获取前端写入的weibo内容
    WeiboAccount.at(currentWeiboAddress).then(function(instance){
        weiboAccountInstance = instance;
        return weiboAccountInstance.sendWeibo(weiboContent,{from:WeiboAccount.web3.eth.accounts[0], gas:defaultGas});
    }).then(function(txReceipt){
        console.info(txReceipt);
        // 显示微博信息
        showWeibo();
        // 清空
        $("#weiboContent").val('');
    })
}

// 在页面中显示微博信息
function showWeibo() {
    // 获取所有微博信息
    getAllWeibo(currentWeiboAddress).then(function(list){
        $("#weiboContentList").html('');
        list.forEach(function(item, index){
            $("#weiboContentList").append("<tr><td>" + item.id + "</td><td>" + item.weiboContent + "</td><td>" + item.timestamp + "</td></tr>");
        });
    });
}

// 获取所有微博信息
async function getAllWeibo(weiboAddress) {
    let weibos = [];
    let total = await getTotalWeibo(weiboAddress) // 已发送微博数量
    for(let i = 0; i< total; i++) {
        let weibo = await getWeibo(weiboAddress,i);
        weibos.push(weibo);
    }
    return weibos;
}

// 获取已发送微博数量
function getTotalWeibo(weiboAddress) {
    return WeiboAccount.at(weiboAddress).then(function(instance){
        return instance.getNumberOfWeibos.call(); //获取数量
    }).then(function(total){
        console.info("total:", total);
        return total;
    })
}

// 获取指定ID的微博信息
function getWeibo(weiboAddress, i) {
    var weiboAccountInstance;
    return WeiboAccount.at(weiboAddress).then(function(instance){
        weiboAccountInstance = instance;
        return weiboAccountInstance.getContentOfId.call(i).then(function(w){
            return {id:i, weiboContent:w[1], timestamp:w[0]};
        });
    });
}

// address->name
function getNameOfAddress() {
    var weiboRegistryInstance;
    return WeiboRegistry.at(weiboRegistryAddress).then(function(instance){
        weiboRegistryInstance = instance;
        return weiboRegistryInstance.getNameOfAccount.call(currentWeiboAddress);
    }).then(function(name){
        $("#myName").html(name);
    })
}

// 获取微博信息
function getWeiboInfo() {
    getNameOfAddress();
    $("#myAccount").html(currentWeiboAddress);
}

// 初始化
window.onload = function() {
    getPlantformInfo(); //显示平台信息
    showAllRegister(); // 显示所有注册账户
    $("#home_tab").click(function(e) {
        e.preventDefault();
        getPlantformInfo(); //显示平台信息
        showAllRegister(); // 显示所有注册账户
    });

    $("#weibo_tab").click(function(e) {
        e.preventDefault();
        getWeiboInfo(); // 显示微博信息
        showWeibo(); //显示微博
    });
    // 注册账号
    $("#registerBtn").click(function(e){
        register();
    });
    // 发送微博
    $("#sendweiboBtn").click(function(e){
        sendWeibo();
    })
}
